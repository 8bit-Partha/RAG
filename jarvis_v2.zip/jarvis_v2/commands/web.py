"""
Web Commands Plugin
Web search, weather, news, Wikipedia, YouTube, email.
"""
import logging
import re
import webbrowser
from datetime import datetime

import requests

from config import OPENWEATHER_API_KEY, NEWS_API_KEY
from core.plugins import PluginBase

logger = logging.getLogger("cmd.web")


class WebPlugin(PluginBase):
    name = "Web"
    description = "Search, weather, news, Wikipedia, YouTube"

    # ── Search ────────────────────────────────────────────────────────────────
    def _search(self, text: str) -> str:
        m = re.search(r"search(?:\s+for)?\s+(.+)", text)
        query = m.group(1).strip() if m else text
        url = f"https://www.google.com/search?q={requests.utils.quote(query)}"
        webbrowser.open(url)
        return f"Searching Google for '{query}'."

    def _youtube(self, text: str) -> str:
        m = re.search(r"(?:youtube|play on youtube)\s+(.+)", text)
        query = m.group(1).strip() if m else text
        url = f"https://www.youtube.com/results?search_query={requests.utils.quote(query)}"
        webbrowser.open(url)
        return f"Opening YouTube search for '{query}'."

    def _wikipedia(self, text: str) -> str:
        m = re.search(r"(?:wikipedia|wiki)\s+(.+)", text)
        topic = m.group(1).strip() if m else text
        url = f"https://en.wikipedia.org/wiki/{requests.utils.quote(topic.replace(' ', '_'))}"
        webbrowser.open(url)
        return f"Opening Wikipedia for '{topic}'."

    # ── Weather ───────────────────────────────────────────────────────────────
    def _weather(self, text: str) -> str:
        m = re.search(r"weather\s+(?:in|at|for)?\s*(.+)", text)
        city = m.group(1).strip() if m else "auto"

        if not OPENWEATHER_API_KEY:
            webbrowser.open(f"https://wttr.in/{city}")
            return f"Opening weather for {city}."

        try:
            params = {"q": city, "appid": OPENWEATHER_API_KEY, "units": "metric"}
            resp = requests.get("https://api.openweathermap.org/data/2.5/weather", params=params, timeout=5)
            data = resp.json()
            desc   = data["weather"][0]["description"].capitalize()
            temp   = data["main"]["temp"]
            feels  = data["main"]["feels_like"]
            humid  = data["main"]["humidity"]
            wind   = data["wind"]["speed"]
            return (f"Weather in {city}: {desc}. "
                    f"Temperature {temp:.0f}°C, feels like {feels:.0f}°C. "
                    f"Humidity {humid}%, wind {wind} m/s.")
        except Exception as e:
            logger.error(f"Weather error: {e}")
            return "Unable to fetch weather right now."

    # ── News ──────────────────────────────────────────────────────────────────
    def _news(self, text: str) -> str:
        if not NEWS_API_KEY:
            webbrowser.open("https://news.google.com")
            return "Opening Google News."
        try:
            m = re.search(r"news\s+(?:about|on)?\s*(.+)", text)
            q = m.group(1).strip() if m else None
            params = {"apiKey": NEWS_API_KEY, "pageSize": 5, "language": "en"}
            if q:
                params["q"] = q
            else:
                params["sources"] = "bbc-news,techcrunch,the-verge"
            resp = requests.get("https://newsapi.org/v2/top-headlines", params=params, timeout=5)
            articles = resp.json().get("articles", [])
            if not articles:
                return "No news found right now."
            headlines = [a["title"] for a in articles[:3]]
            return "Here are the top headlines: " + ". Next: ".join(headlines) + "."
        except Exception as e:
            logger.error(f"News error: {e}")
            return "Couldn't fetch news right now."

    # ── Time / Date ───────────────────────────────────────────────────────────
    def _time(self, text: str) -> str:
        now = datetime.now()
        if "date" in text:
            return f"Today is {now.strftime('%A, %B %d, %Y')}."
        return f"The time is {now.strftime('%I:%M %p')}."

    # ── Open URL ──────────────────────────────────────────────────────────────
    def _open_url(self, text: str) -> str:
        m = re.search(r"(?:open|go to|navigate to|visit)\s+(https?://\S+|[\w.-]+\.(?:com|org|net|io|dev)\S*)", text)
        if not m:
            return "I didn't catch the URL."
        url = m.group(1)
        if not url.startswith("http"):
            url = "https://" + url
        webbrowser.open(url)
        return f"Opening {url}."

    def register(self) -> dict[str, callable]:
        return {
            r"\b(search|google)\b":            self._search,
            r"\byoutube\b":                    self._youtube,
            r"\b(wikipedia|wiki)\b":           self._wikipedia,
            r"\bweather\b":                    self._weather,
            r"\bnews\b":                       self._news,
            r"\b(time|date|day|today)\b":      self._time,
            r"\b(open|go to|navigate|visit)\s+https?": self._open_url,
        }
