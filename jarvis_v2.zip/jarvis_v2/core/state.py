"""
JARVIS State Machine
Manages the assistant lifecycle and shared flags across threads.
"""
from enum import Enum, auto
import threading


class State(Enum):
    SLEEPING    = auto()   # idle, only listening for wake word
    LISTENING   = auto()   # actively capturing user speech
    PROCESSING  = auto()   # sending to Claude / running command
    SPEAKING    = auto()   # TTS playback in progress
    INTERRUPTED = auto()   # user interrupted mid-speech


class StateManager:
    def __init__(self):
        self._state  = State.SLEEPING
        self._lock   = threading.RLock()
        self._events: dict[State, threading.Event] = {s: threading.Event() for s in State}
        self._events[State.SLEEPING].set()

        # Shared flags
        self.stop_speaking   = threading.Event()   # set → interrupt TTS
        self.shutdown        = threading.Event()   # set → exit program
        self.muted           = False

    # ── State access ─────────────────────────────────────────────────────────
    @property
    def state(self) -> State:
        with self._lock:
            return self._state

    @state.setter
    def state(self, new: State):
        with self._lock:
            for e in self._events.values():
                e.clear()
            self._state = new
            self._events[new].set()

    def wait_for(self, target: State, timeout: float | None = None) -> bool:
        return self._events[target].wait(timeout)

    def is_available(self) -> bool:
        """True when JARVIS can accept new commands."""
        return self.state in (State.SLEEPING, State.LISTENING)

    def __repr__(self):
        return f"<StateManager state={self.state.name}>"


# Singleton
manager = StateManager()
