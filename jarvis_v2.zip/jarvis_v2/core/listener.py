"""
JARVIS Listener
Pipeline: Microphone → WebRTC VAD → faster-whisper STT
Supports wake-word detection and continuous listening mode.
"""
import io
import queue
import struct
import threading
import logging
from collections import deque

import numpy as np
import pyaudio
import webrtcvad

from config import (
    STT_ENGINE, WHISPER_MODEL, WHISPER_DEVICE, WHISPER_LANGUAGE,
    WAKE_WORDS, FAREWELL_WORDS, INTERRUPT_WORDS,
    VAD_AGGRESSIVENESS, SILENCE_TIMEOUT_MS, MIN_AUDIO_MS
)
from core.state import manager, State

logger = logging.getLogger("listener")

SAMPLE_RATE  = 16000
FRAME_MS     = 30          # VAD frame size in ms (10 / 20 / 30 only)
FRAME_BYTES  = int(SAMPLE_RATE * FRAME_MS / 1000) * 2   # 16-bit PCM


class Listener:
    def __init__(self):
        self._pa      = pyaudio.PyAudio()
        self._vad     = webrtcvad.Vad(VAD_AGGRESSIVENESS)
        self._stream  = None
        self._model   = None
        self._load_stt()

    # ── STT engine setup ─────────────────────────────────────────────────────
    def _load_stt(self):
        if STT_ENGINE == "whisper":
            try:
                from faster_whisper import WhisperModel
                device = WHISPER_DEVICE
                compute = "float16" if device == "cuda" else "int8"
                self._model = WhisperModel(WHISPER_MODEL, device=device, compute_type=compute)
                logger.info(f"Whisper loaded: {WHISPER_MODEL} on {device}")
            except Exception as e:
                logger.warning(f"faster-whisper unavailable ({e}), falling back to Google STT")
                self._model = None
        else:
            self._model = None

    # ── Audio capture ────────────────────────────────────────────────────────
    def _open_stream(self):
        if self._stream and self._stream.is_active():
            return
        self._stream = self._pa.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=SAMPLE_RATE,
            input=True,
            frames_per_buffer=FRAME_BYTES // 2,
        )

    def _capture_phrase(self) -> bytes | None:
        """
        Capture audio until VAD detects end-of-speech.
        Returns raw 16-bit PCM bytes, or None if too short.
        """
        self._open_stream()
        frames        = []
        silence_ms    = 0
        speech_started = False
        pre_buffer    = deque(maxlen=5)   # ~150ms look-ahead buffer

        while not manager.shutdown.is_set():
            frame = self._stream.read(FRAME_BYTES // 2, exception_on_overflow=False)
            is_speech = self._vad.is_speech(frame, SAMPLE_RATE)

            if not speech_started:
                pre_buffer.append(frame)
                if is_speech:
                    speech_started = True
                    frames.extend(pre_buffer)
                    pre_buffer.clear()
            else:
                frames.append(frame)
                if is_speech:
                    silence_ms = 0
                else:
                    silence_ms += FRAME_MS
                    if silence_ms >= SILENCE_TIMEOUT_MS:
                        break

        if not frames:
            return None

        audio = b"".join(frames)
        duration_ms = len(audio) / 2 / SAMPLE_RATE * 1000
        if duration_ms < MIN_AUDIO_MS:
            return None
        return audio

    # ── Transcription ────────────────────────────────────────────────────────
    def transcribe(self, audio_bytes: bytes) -> str:
        """Convert PCM bytes → text string."""
        if self._model:
            return self._transcribe_whisper(audio_bytes)
        return self._transcribe_google(audio_bytes)

    def _transcribe_whisper(self, audio_bytes: bytes) -> str:
        audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        segments, _ = self._model.transcribe(
            audio_np,
            language=WHISPER_LANGUAGE,
            beam_size=3,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 500},
        )
        return " ".join(s.text.strip() for s in segments).strip()

    def _transcribe_google(self, audio_bytes: bytes) -> str:
        import speech_recognition as sr
        recognizer = sr.Recognizer()
        audio_data = sr.AudioData(audio_bytes, SAMPLE_RATE, 2)
        try:
            return recognizer.recognize_google(audio_data)
        except sr.UnknownValueError:
            return ""
        except sr.RequestError as e:
            logger.error(f"Google STT error: {e}")
            return ""

    # ── Public API ────────────────────────────────────────────────────────────
    def listen_for_wake_word(self) -> bool:
        """
        Passive listen: returns True when a wake word is detected.
        Uses small rolling buffer for low CPU usage.
        """
        manager.state = State.SLEEPING
        logger.debug("Passive listening for wake word…")
        audio = self._capture_phrase()
        if not audio:
            return False
        text = self.transcribe(audio).lower().strip()
        if not text:
            return False
        if any(w in text for w in WAKE_WORDS):
            logger.info(f"Wake word detected in: '{text}'")
            return True
        # Check for interrupt / farewell even in sleep
        if any(w in text for w in INTERRUPT_WORDS + FAREWELL_WORDS):
            manager.stop_speaking.set()
        return False

    def listen_for_command(self) -> str:
        """
        Active listen: captures and transcribes the user's command.
        """
        manager.state = State.LISTENING
        logger.info("Listening for command…")
        audio = self._capture_phrase()
        if not audio:
            return ""
        return self.transcribe(audio).strip()

    def cleanup(self):
        if self._stream:
            self._stream.stop_stream()
            self._stream.close()
        self._pa.terminate()
