"""
JARVIS Brain
Handles intent detection, command routing, and streaming Claude API calls.
LRU-cached for repeated queries. Maintains rolling conversation context.
"""
import json
import logging
import re
from collections import OrderedDict
from typing import Iterator

import anthropic

from config import (
    ANTHROPIC_API_KEY, CLAUDE_MODEL, CLAUDE_MAX_TOKENS,
    CLAUDE_STREAM, CLAUDE_CONTEXT_TURNS, SYSTEM_PROMPT,
    RESPONSE_CACHE_SIZE
)
from core.state import manager, State

logger = logging.getLogger("brain")

# ── Simple LRU cache ──────────────────────────────────────────────────────────
class LRUCache:
    def __init__(self, capacity: int):
        self._cache: OrderedDict[str, str] = OrderedDict()
        self._cap = capacity

    def get(self, key: str) -> str | None:
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]
        return None

    def put(self, key: str, value: str):
        self._cache[key] = value
        self._cache.move_to_end(key)
        if len(self._cache) > self._cap:
            self._cache.popitem(last=False)


# ── Brain ─────────────────────────────────────────────────────────────────────
class Brain:
    def __init__(self, command_registry: dict):
        self._client   = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
        self._cache    = LRUCache(RESPONSE_CACHE_SIZE)
        self._history: list[dict] = []
        self._registry = command_registry   # {pattern: handler_fn}

    # ── Intent routing ────────────────────────────────────────────────────────
    def _route_local(self, text: str) -> str | None:
        """Try to match text against local command patterns first (fast path)."""
        lower = text.lower().strip()
        for pattern, handler in self._registry.items():
            if re.search(pattern, lower):
                try:
                    result = handler(lower)
                    return result or "Done."
                except Exception as e:
                    logger.error(f"Command handler error: {e}")
                    return f"Sorry, I ran into an issue: {e}"
        return None

    # ── Claude call ───────────────────────────────────────────────────────────
    def _call_claude_stream(self, text: str) -> Iterator[str]:
        """Stream Claude response token by token."""
        self._history.append({"role": "user", "content": text})
        # Keep rolling window
        messages = self._history[-(CLAUDE_CONTEXT_TURNS * 2):]

        with self._client.messages.stream(
            model=CLAUDE_MODEL,
            max_tokens=CLAUDE_MAX_TOKENS,
            system=SYSTEM_PROMPT,
            messages=messages,
        ) as stream:
            full_response = ""
            for token in stream.text_stream:
                if manager.stop_speaking.is_set():
                    break
                full_response += token
                yield token

        self._history.append({"role": "assistant", "content": full_response})
        self._cache.put(text.lower(), full_response)

    def _call_claude(self, text: str) -> str:
        cached = self._cache.get(text.lower())
        if cached:
            logger.debug("Cache hit")
            return cached

        self._history.append({"role": "user", "content": text})
        messages = self._history[-(CLAUDE_CONTEXT_TURNS * 2):]

        response = self._client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=CLAUDE_MAX_TOKENS,
            system=SYSTEM_PROMPT,
            messages=messages,
        )
        reply = response.content[0].text
        self._history.append({"role": "assistant", "content": reply})
        self._cache.put(text.lower(), reply)
        return reply

    # ── Public API ────────────────────────────────────────────────────────────
    def process(self, text: str) -> str | Iterator[str]:
        """
        Route command locally first, then fall back to Claude.
        Returns a string or an Iterator[str] for streaming.
        """
        manager.state = State.PROCESSING

        # 1. Local fast-path
        result = self._route_local(text)
        if result is not None:
            return result

        # 2. Claude
        if CLAUDE_STREAM:
            return self._call_claude_stream(text)
        return self._call_claude(text)

    def clear_history(self):
        self._history.clear()
        logger.info("Conversation history cleared.")
