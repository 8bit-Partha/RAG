"""
JARVIS v2 — Main Entry Point
Run: python main.py
"""
import logging
import sys
import time
from pathlib import Path

# ── Logging setup ─────────────────────────────────────────────────────────────
from config import LOG_FILE, DATA_DIR, ASSISTANT_NAME, FAREWELL_WORDS, INTERRUPT_WORDS

DATA_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    handlers=[
        logging.FileHandler(str(LOG_FILE), encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("main")


def main():
    logger.info(f"Starting {ASSISTANT_NAME} v2…")

    # ── Core imports ──────────────────────────────────────────────────────────
    from core.state   import manager, State
    from core.listener import Listener
    from core.speaker  import Speaker
    from core.memory   import Memory
    from core.plugins  import PluginLoader
    from core.brain    import Brain

    # ── Init subsystems ───────────────────────────────────────────────────────
    memory   = Memory()
    speaker  = Speaker()
    listener = Listener()

    # ── Inject dependencies into plugins ─────────────────────────────────────
    try:
        from commands.reminders import set_speaker
        set_speaker(speaker)
    except Exception: pass
    try:
        from commands.memory_cmd import set_memory
        set_memory(memory)
    except Exception: pass

    # ── Load all command plugins ──────────────────────────────────────────────
    loader   = PluginLoader()
    registry = loader.load_all("commands")
    brain    = Brain(registry)

    # ── HUD ───────────────────────────────────────────────────────────────────
    hud = None
    try:
        from gui.hud import HUD
        hud = HUD(manager)
    except Exception as e:
        logger.warning(f"HUD not available: {e}")

    # ── Startup greeting ──────────────────────────────────────────────────────
    speaker.speak(f"Good day. {ASSISTANT_NAME} online. All systems nominal. Say my name to begin.")

    # ── Main loop ─────────────────────────────────────────────────────────────
    logger.info("Entering main loop…")
    try:
        while not manager.shutdown.is_set():

            # 1. Wait for wake word
            if not listener.listen_for_wake_word():
                continue

            speaker.speak("Yes?")
            if hud:
                hud.update_text("Listening…")

            # 2. Capture command
            text = listener.listen_for_command()
            if not text:
                speaker.speak("I didn't catch that.")
                continue

            logger.info(f"Command: {text}")
            if hud:
                hud.update_text(text)

            # 3. Check farewell
            lower = text.lower()
            if any(w in lower for w in FAREWELL_WORDS):
                speaker.speak(f"Understood. Going to sleep. Call my name when you need me.")
                memory.log_command(text, "farewell")
                continue

            # 4. Check interrupt
            if any(w in lower for w in INTERRUPT_WORDS):
                manager.stop_speaking.set()
                speaker.speak("Cancelled.")
                continue

            # 5. Process
            result = brain.process(text)

            # 6. Respond (streaming or instant)
            if hasattr(result, "__iter__") and not isinstance(result, str):
                speaker.speak_stream(result)
            else:
                speaker.speak(str(result))

            # 7. Log
            memory.log_command(text, str(result)[:200] if isinstance(result, str) else "streamed")

    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received.")

    finally:
        speaker.speak("Shutting down. Goodbye.")
        time.sleep(2)
        listener.cleanup()
        memory.close()
        if hud:
            hud.destroy()
        logger.info(f"{ASSISTANT_NAME} terminated.")


if __name__ == "__main__":
    main()
