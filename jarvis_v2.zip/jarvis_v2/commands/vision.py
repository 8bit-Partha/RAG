"""
Vision Commands Plugin
"JARVIS, what's on my screen?" → screenshot + Claude vision
"JARVIS, read the text on screen" → OCR via pytesseract
"""
import base64
import io
import logging
import re

import anthropic
import pyautogui
from PIL import Image

from config import ANTHROPIC_API_KEY, CLAUDE_MODEL
from core.plugins import PluginBase

logger = logging.getLogger("cmd.vision")

_client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)


def _screenshot_b64(region=None) -> str:
    img = pyautogui.screenshot(region=region)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.standard_b64encode(buf.getvalue()).decode()


class VisionPlugin(PluginBase):
    name = "Vision"
    description = "Screen analysis, OCR, describe what JARVIS sees"

    def _describe_screen(self, text: str) -> str:
        """Ask Claude what's on the screen."""
        prompt = "Describe what you see on this computer screen in 2-3 sentences. Be concise."
        if "read" in text or "text" in text or "ocr" in text:
            prompt = "Extract and read aloud all visible text from this screen. Be brief."
        elif "summarize" in text or "summary" in text:
            prompt = "Summarize the main content on this screen in one sentence."
        elif "what app" in text or "which app" in text:
            prompt = "What application or website is currently open on this screen?"
        try:
            b64 = _screenshot_b64()
            response = _client.messages.create(
                model=CLAUDE_MODEL,
                max_tokens=300,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64}},
                        {"type": "text",  "text": prompt}
                    ]
                }]
            )
            return response.content[0].text
        except Exception as e:
            logger.error(f"Vision error: {e}")
            return "I had trouble analysing the screen."

    def _find_on_screen(self, text: str) -> str:
        """Click or locate something on screen using vision."""
        m = re.search(r"(?:find|click|locate|where is)\s+(.+?)(?:\s+on screen)?$", text)
        if not m:
            return "What should I find on screen?"
        target = m.group(1).strip()
        try:
            import pyautogui
            b64 = _screenshot_b64()
            response = _client.messages.create(
                model=CLAUDE_MODEL,
                max_tokens=100,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64}},
                        {"type": "text",  "text": f"Where exactly is '{target}' on this screen? Reply with just approximate x,y pixel coordinates as 'x,y' or 'not found'."}
                    ]
                }]
            )
            coords = response.content[0].text.strip()
            if "not found" in coords.lower():
                return f"I couldn't locate '{target}' on screen."
            xy = coords.split(",")
            x, y = int(xy[0].strip()), int(xy[1].strip())
            pyautogui.moveTo(x, y, duration=0.5)
            return f"Found '{target}' at approximately {x},{y}."
        except Exception as e:
            logger.error(f"Find on screen error: {e}")
            return "I had trouble locating that on screen."

    def register(self) -> dict[str, callable]:
        return {
            r"\b(what(?:'s|\s+is)\s+on\s+(my\s+)?screen|describe\s+(the\s+)?screen|read\s+(the\s+)?screen|ocr|screen\s+text)\b": self._describe_screen,
            r"\b(find|click|locate|where\s+is)\s+.+\s+on\s+screen\b": self._find_on_screen,
            r"\b(summarize|what app|which app)\b.*\bscreen\b": self._describe_screen,
        }
