"""
JARVIS Speaker
Pipeline: text → Edge TTS (streaming) → audio queue → sounddevice playback
Supports mid-speech interruption and sentence-level streaming.
"""
import asyncio
import io
import logging
import queue
import threading

import edge_tts
import sounddevice as sd
import soundfile as sf
import numpy as np

from config import TTS_ENGINE, TTS_VOICE, TTS_RATE, TTS_VOLUME
from core.state import manager, State

logger = logging.getLogger("speaker")


class Speaker:
    def __init__(self):
        self._audio_queue: queue.Queue = queue.Queue(maxsize=8)
        self._player_thread = threading.Thread(target=self._player_loop, daemon=True)
        self._player_thread.start()

    # ── Audio player loop ─────────────────────────────────────────────────────
    def _player_loop(self):
        """Continuously dequeue and play audio chunks."""
        while not manager.shutdown.is_set():
            try:
                chunk = self._audio_queue.get(timeout=0.2)
                if chunk is None:   # sentinel → done speaking
                    manager.state = State.SLEEPING
                    continue
                if manager.stop_speaking.is_set():
                    # Drain the queue on interrupt
                    while not self._audio_queue.empty():
                        self._audio_queue.get_nowait()
                    manager.stop_speaking.clear()
                    manager.state = State.SLEEPING
                    continue
                self._play_chunk(chunk)
            except queue.Empty:
                continue

    def _play_chunk(self, audio_bytes: bytes):
        try:
            buf = io.BytesIO(audio_bytes)
            data, sr = sf.read(buf, dtype="float32")
            sd.play(data, sr, blocking=True)
        except Exception as e:
            logger.warning(f"Audio playback error: {e}")

    # ── Edge TTS ──────────────────────────────────────────────────────────────
    async def _edge_stream(self, text: str):
        communicate = edge_tts.Communicate(text, TTS_VOICE, rate=TTS_RATE, volume=TTS_VOLUME)
        audio_buf = io.BytesIO()
        async for chunk in communicate.stream():
            if manager.stop_speaking.is_set():
                break
            if chunk["type"] == "audio":
                audio_buf.write(chunk["data"])
        audio_buf.seek(0)
        if audio_buf.getbuffer().nbytes > 0:
            self._audio_queue.put(audio_buf.read())

    # ── pyttsx3 fallback ──────────────────────────────────────────────────────
    def _pyttsx3_speak(self, text: str):
        import pyttsx3
        engine = pyttsx3.init()
        engine.setProperty("rate", 185)
        engine.say(text)
        engine.runAndWait()

    # ── Public API ────────────────────────────────────────────────────────────
    def speak(self, text: str):
        """Speak text. Returns immediately; audio plays in background thread."""
        if not text.strip():
            return
        if manager.muted:
            logger.info(f"[MUTED] {text}")
            return

        manager.state = State.SPEAKING
        manager.stop_speaking.clear()
        logger.info(f"Speaking: {text[:80]}…" if len(text) > 80 else f"Speaking: {text}")

        if TTS_ENGINE == "edge":
            asyncio.run(self._edge_stream(text))
        else:
            self._pyttsx3_speak(text)

        self._audio_queue.put(None)   # sentinel

    def speak_stream(self, text_iterator):
        """
        Consume a streaming text iterator sentence by sentence,
        starting TTS playback as soon as the first sentence is complete.
        """
        manager.state = State.SPEAKING
        manager.stop_speaking.clear()
        buffer = ""
        sentence_ends = {".", "!", "?", "…"}

        for token in text_iterator:
            if manager.stop_speaking.is_set():
                break
            buffer += token
            # Flush on sentence boundary
            if buffer[-1] in sentence_ends and len(buffer) > 8:
                asyncio.run(self._edge_stream(buffer.strip()))
                buffer = ""

        if buffer.strip() and not manager.stop_speaking.is_set():
            asyncio.run(self._edge_stream(buffer.strip()))

        self._audio_queue.put(None)

    def stop(self):
        manager.stop_speaking.set()
