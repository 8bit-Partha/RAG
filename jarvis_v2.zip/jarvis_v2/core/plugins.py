"""
JARVIS Plugin System
Each plugin registers regex patterns → handler functions.
"""
import importlib
import logging
import pkgutil
from pathlib import Path

logger = logging.getLogger("plugins")


class PluginBase:
    """Base class for all JARVIS command plugins."""
    name: str = "unnamed"
    description: str = ""

    def register(self) -> dict[str, callable]:
        """
        Return {regex_pattern: handler_function}.
        Patterns are matched against the full lowercased user utterance.
        Handler receives the full text string and returns a response string.
        """
        raise NotImplementedError


class PluginLoader:
    def __init__(self):
        self._registry: dict[str, callable] = {}

    def load_all(self, package_path: str = "commands") -> dict[str, callable]:
        """Auto-discover and load all plugins in the commands package."""
        try:
            pkg = importlib.import_module(package_path)
        except ModuleNotFoundError:
            logger.warning(f"No package '{package_path}' found")
            return {}

        for finder, name, _ in pkgutil.iter_modules(pkg.__path__):
            full_name = f"{package_path}.{name}"
            try:
                mod = importlib.import_module(full_name)
                for attr in dir(mod):
                    cls = getattr(mod, attr)
                    if (isinstance(cls, type)
                            and issubclass(cls, PluginBase)
                            and cls is not PluginBase):
                        plugin = cls()
                        patterns = plugin.register()
                        self._registry.update(patterns)
                        logger.info(f"Loaded plugin: {plugin.name} ({len(patterns)} patterns)")
            except Exception as e:
                logger.error(f"Failed to load plugin {full_name}: {e}")

        return self._registry

    @property
    def registry(self) -> dict[str, callable]:
        return self._registry
