# JARVIS v2 — Advanced AI Voice Assistant

A fully local, streaming, highly optimised personal AI assistant for Windows — modelled after Iron Man's JARVIS.

---

## ⚡ Quick Start

```
1. Double-click setup.bat
2. Paste your Anthropic API key when asked
3. Double-click run.bat  (or: python main.py)
4. Say "JARVIS" and give a command
```

---

## 🏗 Architecture

```
Microphone
    │
    ▼
WebRTC VAD ──► silence filter
    │
    ▼
faster-whisper STT  (local, GPU-accelerated)
    │
    ▼
Plugin Router ──► local handlers (fast path, no API call)
    │                   ├── System (open/close apps, volume, screenshots…)
    │                   ├── Web    (search, weather, news, time…)
    │                   ├── Media  (Spotify, YouTube, media keys…)
    │                   ├── Memory (remember facts, take notes…)
    │                   ├── Vision (screen analysis via Claude vision…)
    │                   └── Reminders (timers, reminders…)
    │
    ▼ (unmatched commands)
Claude Sonnet (streaming)
    │
    ▼
Edge TTS (sentence-level streaming) ──► sounddevice playback
    │
    ▼
HUD overlay (tkinter, always on top)
```

---

## 🎤 Voice Commands

| Say…                                        | Does…                           |
|---------------------------------------------|---------------------------------|
| "JARVIS, open Chrome"                       | Launches Chrome                 |
| "JARVIS, close Spotify"                     | Kills Spotify process           |
| "JARVIS, volume up / set volume to 60"      | Adjusts system volume           |
| "JARVIS, take a screenshot"                 | Saves PNG to Desktop            |
| "JARVIS, what's on my screen?"              | Claude vision describes screen  |
| "JARVIS, search for quantum computing"      | Google search                   |
| "JARVIS, weather in Tokyo"                  | Current weather                 |
| "JARVIS, latest tech news"                  | Top 3 headlines                 |
| "JARVIS, remind me in 20 minutes to eat"    | Timed reminder                  |
| "JARVIS, remember my birthday is July 4th"  | Stores in SQLite memory         |
| "JARVIS, what's my birthday?"               | Recalls stored fact             |
| "JARVIS, take a note: buy milk"             | Saves to notes DB               |
| "JARVIS, system info"                       | CPU / RAM / Disk / GPU stats    |
| "JARVIS, shutdown / restart / sleep"        | Power commands                  |
| "JARVIS, play Bohemian Rhapsody on Spotify" | Opens Spotify search            |
| "Stop" / "Cancel"                           | Interrupts speech mid-sentence  |
| "Goodbye"                                   | Returns to passive listening    |

---

## ⚙️ Configuration (`config.py`)

| Setting           | Default          | Options                    |
|-------------------|------------------|----------------------------|
| `STT_ENGINE`      | `"whisper"`      | `"whisper"` / `"google"`   |
| `WHISPER_MODEL`   | `"base"`         | tiny / base / small / medium / large |
| `WHISPER_DEVICE`  | `"cuda"`         | `"cuda"` / `"cpu"`         |
| `TTS_ENGINE`      | `"edge"`         | `"edge"` / `"pyttsx3"`     |
| `TTS_VOICE`       | `en-US-GuyNeural`| any Edge TTS voice         |
| `GUI_THEME`       | `"arc"`          | `"arc"` / `"gold"` / `"green"` |
| `GUI_POSITION`    | `"bottom-right"` | corner positions           |

### Adding custom apps
Edit `CUSTOM_APPS` in `config.py`:
```python
CUSTOM_APPS = {
    "blender": r"C:\Program Files\Blender Foundation\Blender\blender.exe",
}
```
Then say: *"JARVIS, open Blender"*

---

## 🔑 API Keys

| Service        | Required? | Where to get                     |
|----------------|-----------|----------------------------------|
| Anthropic       | ✅ Yes    | console.anthropic.com            |
| OpenWeatherMap  | Optional  | openweathermap.org (free tier)   |
| NewsAPI         | Optional  | newsapi.org (free tier)          |

---

## 📦 Adding Custom Plugins

Create a file in `commands/myplugin.py`:

```python
from core.plugins import PluginBase

class MyPlugin(PluginBase):
    name = "MyPlugin"

    def register(self):
        return {
            r"\bhello world\b": self._hello,
        }

    def _hello(self, text: str) -> str:
        return "Hello, world!"
```

That's it — it auto-loads on next startup.

---

## 🔧 Performance Tips

- **Fastest STT**: Use `WHISPER_MODEL = "tiny"` on CPU, `"small"` on GPU
- **No internet needed**: Set `STT_ENGINE = "whisper"` and `TTS_ENGINE = "pyttsx3"`
- **Reduce latency**: Lower `CLAUDE_MAX_TOKENS` to 256 for snappier replies
