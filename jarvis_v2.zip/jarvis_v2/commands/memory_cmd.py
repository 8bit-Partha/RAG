"""
Memory Commands Plugin
"Remember that my API key is XYZ"
"What did you remember about my name?"
"Forget my password"
"Take a note: buy milk"
"""
import re
from core.plugins import PluginBase

# Injected by main.py
_memory = None

def set_memory(memory):
    global _memory
    _memory = memory


class MemoryPlugin(PluginBase):
    name = "Memory"
    description = "Remember facts, take notes, recall information"

    def _remember(self, text: str) -> str:
        # "remember that X is Y" / "remember my X is Y"
        m = re.search(r"remember\s+(?:that\s+)?(?:my\s+)?(.+?)\s+is\s+(.+)", text)
        if not m:
            m = re.search(r"remember\s+(.+)", text)
            if m:
                _memory.remember(m.group(1).strip(), "noted")
                return f"Noted: {m.group(1).strip()}."
            return "What should I remember? Try: 'Remember my name is Tony'."
        key, value = m.group(1).strip(), m.group(2).strip()
        _memory.remember(key, value)
        return f"Remembered: your {key} is {value}."

    def _recall(self, text: str) -> str:
        m = re.search(r"(?:what(?:'s|\s+is|.*\s+is)\s+(?:my\s+)?|recall\s+(?:my\s+)?)(.+?)(?:\??)?$", text)
        if not m:
            return "What would you like me to recall?"
        key = m.group(1).strip().rstrip("?")
        value = _memory.recall(key)
        if value:
            return f"Your {key} is {value}."
        return f"I don't have anything stored for '{key}'."

    def _forget(self, text: str) -> str:
        m = re.search(r"forget\s+(?:my\s+)?(.+)", text)
        if not m:
            return "What should I forget?"
        key = m.group(1).strip()
        _memory.forget(key)
        return f"Forgotten: {key}."

    def _take_note(self, text: str) -> str:
        m = re.search(r"(?:take\s+a?\s*note|note\s+this|write\s+this\s+down)[:\s]+(.+)", text)
        if not m:
            return "What should I note down?"
        body = m.group(1).strip()
        _memory.save_note(body)
        return f"Note saved: {body}."

    def _get_notes(self, text: str) -> str:
        notes = _memory.get_notes(limit=5)
        if not notes:
            return "You have no saved notes."
        items = [f"'{n['body']}'" for n in notes]
        return "Your recent notes: " + "; ".join(items) + "."

    def _list_facts(self, text: str) -> str:
        facts = _memory.list_facts()
        if not facts:
            return "I haven't stored any facts yet."
        items = [f"{k}: {v}" for k, v in facts[:5]]
        return "What I know about you: " + "; ".join(items) + "."

    def register(self) -> dict[str, callable]:
        return {
            r"\bremember\b(?!.*\bto\b)":   self._remember,
            r"\b(recall|what.*is my|what.*was my)\b": self._recall,
            r"\bforget\b":                 self._forget,
            r"\b(take a note|note this|write this down)\b": self._take_note,
            r"\b(my notes|show notes|read notes)\b": self._get_notes,
            r"\b(what do you know|list.*facts|my facts)\b": self._list_facts,
        }
