"""
Reminders & Timers Plugin
"Remind me in 30 minutes to call John"
"Set a timer for 5 minutes"
"What are my reminders?"
"""
import logging
import re
import sqlite3
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from config import REMINDERS_DB
from core.plugins import PluginBase

logger = logging.getLogger("cmd.reminders")

# Will be injected by main.py
_speaker = None


def set_speaker(speaker):
    global _speaker
    _speaker = speaker


class ReminderPlugin(PluginBase):
    name = "Reminders"
    description = "Set reminders, timers, alarms"

    def __init__(self):
        REMINDERS_DB.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(REMINDERS_DB), check_same_thread=False)
        self._lock = threading.Lock()
        self._init_db()
        self._start_watcher()

    def _init_db(self):
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS reminders (
                    id       INTEGER PRIMARY KEY AUTOINCREMENT,
                    message  TEXT,
                    fire_at  REAL,
                    fired    INTEGER DEFAULT 0
                )
            """)

    def _start_watcher(self):
        def watch():
            while True:
                time.sleep(5)
                self._check_reminders()
        t = threading.Thread(target=watch, daemon=True)
        t.start()

    def _check_reminders(self):
        now = time.time()
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, message FROM reminders WHERE fire_at <= ? AND fired=0", (now,)
            ).fetchall()
            for rid, msg in rows:
                if _speaker:
                    _speaker.speak(f"Reminder: {msg}")
                logger.info(f"Fired reminder: {msg}")
                self._conn.execute("UPDATE reminders SET fired=1 WHERE id=?", (rid,))
            self._conn.commit()

    def _parse_time_delta(self, text: str) -> int | None:
        """Return seconds from text like '5 minutes', '1 hour 30 minutes'."""
        total = 0
        patterns = [
            (r"(\d+)\s*(?:hour|hr)s?",   3600),
            (r"(\d+)\s*(?:minute|min)s?", 60),
            (r"(\d+)\s*(?:second|sec)s?", 1),
        ]
        for pat, mult in patterns:
            m = re.search(pat, text)
            if m:
                total += int(m.group(1)) * mult
        return total if total > 0 else None

    def _set_reminder(self, text: str) -> str:
        # "remind me in X to Y" / "remind me to Y in X"
        m = re.search(r"remind\s+me\s+(?:in\s+(.+?)\s+to\s+(.+)|to\s+(.+?)\s+in\s+(.+))", text)
        if not m:
            return "Try: 'Remind me in 10 minutes to take a break'."
        if m.group(1):
            time_str, msg = m.group(1), m.group(2)
        else:
            msg, time_str = m.group(3), m.group(4)
        secs = self._parse_time_delta(time_str)
        if not secs:
            return "I couldn't understand the time. Try '10 minutes' or '1 hour'."
        fire_at = time.time() + secs
        with self._lock:
            self._conn.execute(
                "INSERT INTO reminders(message, fire_at) VALUES(?,?)", (msg, fire_at)
            )
            self._conn.commit()
        human = str(timedelta(seconds=secs))
        return f"Got it. I'll remind you to {msg} in {time_str}."

    def _set_timer(self, text: str) -> str:
        secs = self._parse_time_delta(text)
        if not secs:
            return "I didn't catch the duration. Try 'timer for 5 minutes'."
        fire_at = time.time() + secs
        with self._lock:
            self._conn.execute(
                "INSERT INTO reminders(message, fire_at) VALUES(?,?)", ("Timer done!", fire_at)
            )
            self._conn.commit()
        return f"Timer set for {secs // 60} minute{'s' if secs >= 120 else ''}."

    def _list_reminders(self, text: str) -> str:
        with self._lock:
            rows = self._conn.execute(
                "SELECT message, fire_at FROM reminders WHERE fired=0 ORDER BY fire_at"
            ).fetchall()
        if not rows:
            return "You have no pending reminders."
        items = []
        for msg, fire_at in rows:
            remaining = int(fire_at - time.time())
            if remaining > 0:
                mins = remaining // 60
                secs = remaining % 60
                items.append(f"{msg} in {mins}m {secs}s")
        return "Pending reminders: " + "; ".join(items) + "." if items else "No active reminders."

    def _clear_reminders(self, text: str) -> str:
        with self._lock:
            self._conn.execute("UPDATE reminders SET fired=1 WHERE fired=0")
            self._conn.commit()
        return "All reminders cleared."

    def register(self) -> dict[str, callable]:
        return {
            r"\bremind\s+me\b":              self._set_reminder,
            r"\b(set\s+a?\s*timer|timer\s+for)\b": self._set_timer,
            r"\b(my\s+reminders|list\s+reminders|what.*reminders)\b": self._list_reminders,
            r"\bclear\s+(?:all\s+)?reminders\b": self._clear_reminders,
        }
