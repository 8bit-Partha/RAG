@echo off
TITLE JARVIS v2 Setup
color 0B

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║         JARVIS v2 — Setup Wizard         ║
echo  ╚══════════════════════════════════════════╝
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+ from python.org
    pause & exit /b 1
)

echo [1/5] Upgrading pip...
python -m pip install --upgrade pip --quiet

echo [2/5] Installing dependencies...
python -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo [WARN] Some packages failed. Trying one by one...
    for /F %%p in (requirements.txt) do (
        python -m pip install %%p --quiet 2>nul
    )
)

echo [3/5] Installing faster-whisper (recommended STT)...
python -m pip install faster-whisper --quiet
if errorlevel 1 (
    echo [WARN] faster-whisper not installed. Will use Google STT.
)

echo [4/5] Checking CUDA (for GPU acceleration)...
python -c "import torch; print('CUDA available:', torch.cuda.is_available())" 2>nul || echo [INFO] PyTorch not found — whisper will use CPU (still fast).

echo.
echo [5/5] API Key Configuration
echo ─────────────────────────────────────────────
set /p ANTHKEY="Paste your Anthropic API key (sk-ant-...): "
set /p WEATHERKEY="OpenWeatherMap API key (press Enter to skip): "
set /p NEWSKEY="NewsAPI key (press Enter to skip): "

:: Write .env file
(
echo ANTHROPIC_API_KEY=%ANTHKEY%
echo OPENWEATHER_API_KEY=%WEATHERKEY%
echo NEWS_API_KEY=%NEWSKEY%
) > .env

:: Apply .env vars for current session
for /F "tokens=1,2 delims==" %%A in (.env) do set %%A=%%B

echo.
echo ═══════════════════════════════════════════════
echo  ✓ Setup complete!
echo.
echo  To start JARVIS:   python main.py
echo  To configure:      notepad config.py
echo.
echo  Voice commands to try:
echo    "JARVIS, open Chrome"
echo    "JARVIS, what's the weather in London?"
echo    "JARVIS, take a screenshot"
echo    "JARVIS, remind me in 10 minutes to take a break"
echo    "JARVIS, what's on my screen?"
echo    "JARVIS, set volume to 40"
echo    "Goodbye" — puts JARVIS to sleep
echo ═══════════════════════════════════════════════
echo.
pause
