"""
JARVIS HUD Overlay
Floating transparent window showing status, last command, waveform indicator.
Runs in its own thread. Tkinter-based, works on Windows without extra deps.
"""
import math
import random
import threading
import tkinter as tk
import time

from config import GUI_ENABLED, GUI_OPACITY, GUI_POSITION, GUI_THEME

# Theme palettes
THEMES = {
    "arc":  {"bg": "#050d1a", "accent": "#00bfff", "text": "#e0f0ff", "dim": "#1a3a5c"},
    "gold": {"bg": "#0f0a00", "accent": "#ffd700", "text": "#fff8dc", "dim": "#3a2a00"},
    "green":{"bg": "#001a00", "accent": "#00ff88", "text": "#e0ffe8", "dim": "#003a10"},
}


class HUD:
    def __init__(self, state_manager):
        if not GUI_ENABLED:
            return
        self._sm     = state_manager
        self._theme  = THEMES.get(GUI_THEME, THEMES["arc"])
        self._root   = None
        self._status_var = None
        self._text_var   = None
        self._canvas     = None
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        import tkinter as tk
        C = self._theme
        self._root = tk.Tk()
        root = self._root
        root.title("JARVIS HUD")
        root.overrideredirect(True)          # no window border
        root.attributes("-topmost", True)
        root.attributes("-alpha", GUI_OPACITY)
        root.configure(bg=C["bg"])

        W, H = 340, 130
        self._position_window(W, H)

        # ── Waveform canvas ───────────────────────────────────────────────────
        self._canvas = tk.Canvas(root, width=W, height=50, bg=C["bg"], highlightthickness=0)
        self._canvas.pack(padx=10, pady=(10, 0))

        # ── Status label ──────────────────────────────────────────────────────
        self._status_var = tk.StringVar(value="● SLEEPING")
        tk.Label(root, textvariable=self._status_var,
                 fg=C["accent"], bg=C["bg"],
                 font=("Consolas", 11, "bold")).pack(anchor="w", padx=12)

        # ── Last command label ────────────────────────────────────────────────
        self._text_var = tk.StringVar(value="")
        tk.Label(root, textvariable=self._text_var,
                 fg=C["text"], bg=C["bg"],
                 font=("Consolas", 9), wraplength=310, justify="left").pack(anchor="w", padx=12, pady=(0, 8))

        # ── Drag to move ──────────────────────────────────────────────────────
        root.bind("<Button-1>",   self._drag_start)
        root.bind("<B1-Motion>",  self._drag_move)

        # Start update loop
        self._animate()
        root.mainloop()

    def _position_window(self, W, H):
        root = self._root
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        margin = 18
        positions = {
            "top-left":      (margin, margin),
            "top-right":     (sw - W - margin, margin),
            "bottom-left":   (margin, sh - H - margin - 42),
            "bottom-right":  (sw - W - margin, sh - H - margin - 42),
        }
        x, y = positions.get(GUI_POSITION, positions["bottom-right"])
        root.geometry(f"{W}x{H}+{x}+{y}")

    def _drag_start(self, e):
        self._dx = e.x
        self._dy = e.y

    def _drag_move(self, e):
        x = self._root.winfo_x() + e.x - self._dx
        y = self._root.winfo_y() + e.y - self._dy
        self._root.geometry(f"+{x}+{y}")

    def _animate(self):
        C = self._theme
        state = self._sm.state.name
        canvas = self._canvas
        canvas.delete("all")
        W, H = 340, 50
        bars = 28

        # Color per state
        color_map = {
            "SLEEPING":    C["dim"],
            "LISTENING":   C["accent"],
            "PROCESSING":  "#ff9900",
            "SPEAKING":    "#00ff88",
            "INTERRUPTED": "#ff4444",
        }
        try:
            color = color_map.get(state, C["accent"])
        except Exception:
            color = C["accent"]

        for i in range(bars):
            x = 10 + i * (W - 20) / bars
            if state == "SLEEPING":
                amp = 4 + math.sin(time.time() * 0.8 + i * 0.4) * 2
            elif state == "LISTENING":
                amp = random.uniform(5, 28)
            elif state == "PROCESSING":
                amp = 10 + math.sin(time.time() * 4 + i * 0.6) * 8
            else:
                amp = 8 + math.sin(time.time() * 2 + i * 0.5) * 10
            canvas.create_rectangle(x, H/2 - amp, x + 6, H/2 + amp,
                                    fill=color, outline="")

        # Status text
        labels = {
            "SLEEPING": "● STANDBY",
            "LISTENING": "◉ LISTENING",
            "PROCESSING": "⚙ PROCESSING",
            "SPEAKING": "▶ SPEAKING",
            "INTERRUPTED": "■ INTERRUPTED",
        }
        if self._status_var:
            self._status_var.set(labels.get(state, state))

        self._root.after(60, self._animate)   # ~16 fps

    def update_text(self, text: str):
        if self._text_var and text:
            short = text[:60] + "…" if len(text) > 60 else text
            self._text_var.set(f"» {short}")

    def destroy(self):
        if self._root:
            self._root.quit()
