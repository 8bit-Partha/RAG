"""
JARVIS Memory
SQLite-backed key-value + note storage with fuzzy recall.
"""
import json
import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

from config import MEMORY_DB

logger = logging.getLogger("memory")


class Memory:
    def __init__(self):
        MEMORY_DB.parent.mkdir(parents=True, exist_ok=True)
        self._conn  = sqlite3.connect(str(MEMORY_DB), check_same_thread=False)
        self._lock  = threading.Lock()
        self._init_db()

    def _init_db(self):
        with self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS facts (
                    key   TEXT PRIMARY KEY,
                    value TEXT,
                    ts    TEXT
                );
                CREATE TABLE IF NOT EXISTS notes (
                    id    INTEGER PRIMARY KEY AUTOINCREMENT,
                    tag   TEXT,
                    body  TEXT,
                    ts    TEXT
                );
                CREATE TABLE IF NOT EXISTS command_log (
                    id      INTEGER PRIMARY KEY AUTOINCREMENT,
                    command TEXT,
                    result  TEXT,
                    ts      TEXT
                );
            """)

    # ── Facts ─────────────────────────────────────────────────────────────────
    def remember(self, key: str, value: str):
        ts = datetime.now().isoformat()
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO facts(key, value, ts) VALUES(?,?,?)",
                (key.lower(), value, ts)
            )
            self._conn.commit()
        logger.info(f"Remembered: {key} = {value}")

    def recall(self, key: str) -> str | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT value FROM facts WHERE key=?", (key.lower(),)
            ).fetchone()
        return row[0] if row else None

    def forget(self, key: str):
        with self._lock:
            self._conn.execute("DELETE FROM facts WHERE key=?", (key.lower(),))
            self._conn.commit()

    def list_facts(self) -> list[tuple[str, str]]:
        with self._lock:
            return self._conn.execute(
                "SELECT key, value FROM facts ORDER BY ts DESC"
            ).fetchall()

    # ── Notes ─────────────────────────────────────────────────────────────────
    def save_note(self, body: str, tag: str = "general"):
        ts = datetime.now().isoformat()
        with self._lock:
            self._conn.execute(
                "INSERT INTO notes(tag, body, ts) VALUES(?,?,?)", (tag, body, ts)
            )
            self._conn.commit()

    def get_notes(self, tag: str = None, limit: int = 10) -> list[dict]:
        with self._lock:
            if tag:
                rows = self._conn.execute(
                    "SELECT tag, body, ts FROM notes WHERE tag=? ORDER BY ts DESC LIMIT ?",
                    (tag, limit)
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT tag, body, ts FROM notes ORDER BY ts DESC LIMIT ?", (limit,)
                ).fetchall()
        return [{"tag": r[0], "body": r[1], "ts": r[2]} for r in rows]

    # ── Command log ───────────────────────────────────────────────────────────
    def log_command(self, command: str, result: str):
        ts = datetime.now().isoformat()
        with self._lock:
            self._conn.execute(
                "INSERT INTO command_log(command, result, ts) VALUES(?,?,?)",
                (command, result[:200], ts)
            )
            self._conn.commit()

    def recent_commands(self, limit: int = 5) -> list[str]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT command FROM command_log ORDER BY ts DESC LIMIT ?", (limit,)
            ).fetchall()
        return [r[0] for r in rows]

    def close(self):
        self._conn.close()
