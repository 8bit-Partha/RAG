"""
JARVIS v2 — Master Configuration
Edit this file to customize your assistant.
"""
import os
from pathlib import Path

# ── Identity ─────────────────────────────────────────────────────────────────
ASSISTANT_NAME   = "JARVIS"
WAKE_WORDS       = ["jarvis", "hey jarvis", "ok jarvis"]
FAREWELL_WORDS   = ["goodbye", "go to sleep", "sleep mode", "that's all"]
INTERRUPT_WORDS  = ["stop", "cancel", "shut up"]

# ── API Keys (set via setup.bat or .env) ─────────────────────────────────────
ANTHROPIC_API_KEY     = os.getenv("ANTHROPIC_API_KEY", "")
OPENWEATHER_API_KEY   = os.getenv("OPENWEATHER_API_KEY", "")   # free at openweathermap.org
NEWS_API_KEY          = os.getenv("NEWS_API_KEY", "")          # free at newsapi.org
SPOTIFY_CLIENT_ID     = os.getenv("SPOTIFY_CLIENT_ID", "")
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET", "")

# ── Speech-to-Text ────────────────────────────────────────────────────────────
# Options: "google" (free, needs internet) | "whisper" (local, accurate)
STT_ENGINE       = "whisper"
WHISPER_MODEL    = "base"        # tiny / base / small / medium / large
WHISPER_DEVICE   = "cuda"        # cuda | cpu  (auto-falls back to cpu)
WHISPER_LANGUAGE = "en"

# ── Text-to-Speech ────────────────────────────────────────────────────────────
# Options: "edge" (free, natural, streaming) | "pyttsx3" (offline, basic)
TTS_ENGINE       = "edge"
TTS_VOICE        = "en-US-GuyNeural"   # Edge TTS voice name
TTS_RATE         = "+10%"              # speed: -50% to +50%
TTS_VOLUME       = "+0%"

# ── Claude Brain ──────────────────────────────────────────────────────────────
CLAUDE_MODEL          = "claude-sonnet-4-20250514"
CLAUDE_MAX_TOKENS     = 512
CLAUDE_STREAM         = True     # stream response word by word
CLAUDE_CONTEXT_TURNS  = 10       # how many prior turns to keep

SYSTEM_PROMPT = f"""You are {ASSISTANT_NAME}, an advanced AI assistant integrated into the user's Windows PC — modeled after Tony Stark's JARVIS. You are concise, intelligent, and slightly witty. 
- Respond in 1-3 short sentences unless asked for detail.
- When you perform an action, confirm it briefly (e.g. "Done.", "Opening Chrome now.").
- If you cannot do something, say so plainly and suggest an alternative.
- Never break character. You are always {ASSISTANT_NAME}."""

# ── Voice Activity Detection ──────────────────────────────────────────────────
VAD_AGGRESSIVENESS   = 2         # 0-3 (3 = most aggressive noise filtering)
SILENCE_TIMEOUT_MS   = 1200      # ms of silence before stopping capture
MIN_AUDIO_MS         = 400       # discard clips shorter than this

# ── Performance ───────────────────────────────────────────────────────────────
RESPONSE_CACHE_SIZE  = 128       # LRU cache entries for repeated queries
MAX_THREAD_WORKERS   = 6

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent
DATA_DIR       = BASE_DIR / "data"
LOG_FILE       = DATA_DIR / "jarvis.log"
MEMORY_DB      = DATA_DIR / "memory.db"
REMINDERS_DB   = DATA_DIR / "reminders.db"

# ── GUI / HUD ─────────────────────────────────────────────────────────────────
GUI_ENABLED       = True
GUI_OPACITY       = 0.92
GUI_POSITION      = "bottom-right"   # top-left | top-right | bottom-left | bottom-right
GUI_THEME         = "arc"            # arc (blue) | gold | green

# ── Custom App Paths ──────────────────────────────────────────────────────────
# Add your own: "name": r"C:\path\to\app.exe"
CUSTOM_APPS: dict[str, str] = {
    "vscode":      r"C:\Users\%USERNAME%\AppData\Local\Programs\Microsoft VS Code\Code.exe",
    "spotify":     r"C:\Users\%USERNAME%\AppData\Roaming\Spotify\Spotify.exe",
    "discord":     r"C:\Users\%USERNAME%\AppData\Local\Discord\Update.exe --processStart Discord.exe",
    "steam":       r"C:\Program Files (x86)\Steam\steam.exe",
    "obs":         r"C:\Program Files\obs-studio\bin\64bit\obs64.exe",
}

# ── Home Assistant (optional) ─────────────────────────────────────────────────
HA_URL   = os.getenv("HA_URL", "http://homeassistant.local:8123")
HA_TOKEN = os.getenv("HA_TOKEN", "")
