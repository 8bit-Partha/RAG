"""
Media Commands Plugin
Spotify control, YouTube playback, system media keys.
"""
import logging
import re
import subprocess
import webbrowser

from core.plugins import PluginBase

logger = logging.getLogger("cmd.media")


def _media_key(key: str):
    """Send a media key via PowerShell."""
    import subprocess
    codes = {
        "play":  "179", "pause": "179", "stop":  "178",
        "next":  "176", "previous": "177", "mute": "173",
    }
    code = codes.get(key)
    if code:
        subprocess.Popen(
            ["powershell", "-c",
             f"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]{code})"],
            creationflags=subprocess.CREATE_NO_WINDOW
        )


class MediaPlugin(PluginBase):
    name = "Media"
    description = "Music playback, Spotify, YouTube, media keys"

    def _play_pause(self, text: str) -> str:
        _media_key("play")
        return "Toggling playback."

    def _next_track(self, text: str) -> str:
        _media_key("next")
        return "Skipping to next track."

    def _prev_track(self, text: str) -> str:
        _media_key("previous")
        return "Going back to previous track."

    def _play_spotify(self, text: str) -> str:
        m = re.search(r"(?:play|listen to)\s+(.+?)(?:\s+on spotify)?$", text)
        if not m:
            _media_key("play")
            return "Resuming playback."
        query = m.group(1).strip()
        url = f"https://open.spotify.com/search/{query.replace(' ', '%20')}"
        webbrowser.open(url)
        return f"Searching Spotify for '{query}'."

    def _play_youtube(self, text: str) -> str:
        m = re.search(r"(?:play|watch)\s+(.+?)\s+on youtube", text)
        if not m:
            m = re.search(r"youtube\s+(.+)", text)
        query = m.group(1).strip() if m else "music"
        url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
        webbrowser.open(url)
        return f"Searching YouTube for '{query}'."

    def register(self) -> dict[str, callable]:
        return {
            r"\b(pause|resume|play music)\b": self._play_pause,
            r"\bnext\s+(track|song)\b":       self._next_track,
            r"\b(previous|last)\s+(track|song|music)\b": self._prev_track,
            r"\bplay\s+.+\s+on\s+spotify\b":  self._play_spotify,
            r"\bspotify\b":                   self._play_spotify,
            r"\bplay\s+.+\s+on\s+youtube\b":  self._play_youtube,
        }
