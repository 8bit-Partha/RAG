"""
System Commands Plugin
Open/close apps, volume, brightness, screenshots, shutdown, clipboard, etc.
"""
import logging
import os
import re
import subprocess
import time
from pathlib import Path

from core.plugins import PluginBase

logger = logging.getLogger("cmd.system")


def _run(cmd: list[str] | str, shell=False):
    try:
        subprocess.Popen(cmd, shell=shell, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        logger.error(f"run error: {e}")


class SystemPlugin(PluginBase):
    name = "System"
    description = "App management, volume, brightness, shutdown, screenshots, clipboard"

    # ── App registry ──────────────────────────────────────────────────────────
    BUILTIN_APPS = {
        "chrome":      "chrome",
        "google chrome": "chrome",
        "firefox":     "firefox",
        "notepad":     "notepad",
        "calculator":  "calc",
        "explorer":    "explorer",
        "file explorer": "explorer",
        "task manager":"taskmgr",
        "paint":       "mspaint",
        "word":        "winword",
        "excel":       "excel",
        "powerpoint":  "powerpnt",
        "cmd":         "cmd",
        "command prompt": "cmd",
        "powershell":  "powershell",
        "settings":    "ms-settings:",
        "control panel": "control",
        "edge":        "msedge",
    }

    def _resolve_app(self, name: str) -> str | None:
        from config import CUSTOM_APPS
        name = name.strip()
        if name in self.BUILTIN_APPS:
            return self.BUILTIN_APPS[name]
        for key, path in CUSTOM_APPS.items():
            if key in name:
                return os.path.expandvars(path)
        return None

    # ── Handlers ──────────────────────────────────────────────────────────────
    def _open_app(self, text: str) -> str:
        m = re.search(r"open\s+(.+?)(?:\s+please)?$", text)
        if not m:
            return "What would you like me to open?"
        app_name = m.group(1).strip()
        cmd = self._resolve_app(app_name)
        if cmd:
            _run(cmd, shell=True)
            return f"Opening {app_name}."
        # Fallback: try to run it directly
        _run(app_name, shell=True)
        return f"Attempting to open {app_name}."

    def _close_app(self, text: str) -> str:
        m = re.search(r"close\s+(.+)", text)
        if not m:
            return "Which application should I close?"
        app = m.group(1).strip()
        # Map friendly names to process names
        procs = {
            "chrome": "chrome.exe", "firefox": "firefox.exe",
            "notepad": "notepad.exe", "calculator": "calculator.exe",
            "edge": "msedge.exe", "spotify": "Spotify.exe",
            "discord": "Discord.exe", "steam": "steam.exe",
        }
        proc = procs.get(app.lower(), app + ".exe")
        _run(["taskkill", "/F", "/IM", proc])
        return f"Closing {app}."

    def _volume(self, text: str) -> str:
        import ctypes
        from ctypes import cast, POINTER
        try:
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))

            if "mute" in text:
                volume.SetMute(1, None)
                return "Audio muted."
            if "unmute" in text or "un-mute" in text:
                volume.SetMute(0, None)
                return "Audio unmuted."
            if "up" in text or "raise" in text or "increase" in text:
                vol = min(1.0, volume.GetMasterVolumeLevelScalar() + 0.1)
                volume.SetMasterVolumeLevelScalar(vol, None)
                return f"Volume set to {int(vol*100)}%."
            if "down" in text or "lower" in text or "decrease" in text:
                vol = max(0.0, volume.GetMasterVolumeLevelScalar() - 0.1)
                volume.SetMasterVolumeLevelScalar(vol, None)
                return f"Volume set to {int(vol*100)}%."
            # set to XX
            m = re.search(r"(\d+)\s*(?:percent|%)?", text)
            if m:
                val = min(100, max(0, int(m.group(1))))
                volume.SetMasterVolumeLevelScalar(val / 100, None)
                return f"Volume set to {val}%."
        except Exception as e:
            # Fallback via nircmd
            if "up" in text:
                _run("nircmd.exe changesysvolume 6553")
            elif "down" in text:
                _run("nircmd.exe changesysvolume -6553")
            elif "mute" in text:
                _run("nircmd.exe mutesysvolume 1")
        return "Volume adjusted."

    def _screenshot(self, text: str) -> str:
        import pyautogui
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = Path.home() / "Desktop" / f"jarvis_screenshot_{ts}.png"
        pyautogui.screenshot(str(path))
        return f"Screenshot saved to your Desktop as jarvis_screenshot_{ts}.png."

    def _shutdown(self, text: str) -> str:
        if "restart" in text or "reboot" in text:
            _run("shutdown /r /t 10", shell=True)
            return "Restarting in 10 seconds. You can cancel with 'shutdown /a'."
        if "sleep" in text or "hibernate" in text:
            _run("rundll32.exe powrprof.dll,SetSuspendState 0,1,0", shell=True)
            return "Putting the system to sleep."
        if "lock" in text:
            _run("rundll32.exe user32.dll,LockWorkStation", shell=True)
            return "Locking the screen."
        _run("shutdown /s /t 30", shell=True)
        return "Shutting down in 30 seconds. Say 'cancel shutdown' to abort."

    def _cancel_shutdown(self, text: str) -> str:
        _run("shutdown /a", shell=True)
        return "Shutdown cancelled."

    def _clipboard(self, text: str) -> str:
        import pyperclip
        if "read" in text or "what" in text or "paste" in text:
            content = pyperclip.paste()
            if not content:
                return "The clipboard is empty."
            preview = content[:200] + "…" if len(content) > 200 else content
            return f"Clipboard contains: {preview}"
        m = re.search(r"copy\s+(.+)", text)
        if m:
            pyperclip.copy(m.group(1).strip())
            return "Copied to clipboard."
        return "What should I do with the clipboard?"

    def _type_text(self, text: str) -> str:
        import pyautogui
        m = re.search(r"type\s+(.+)", text)
        if not m:
            return "What should I type?"
        pyautogui.typewrite(m.group(1).strip(), interval=0.03)
        return "Done typing."

    def _key_press(self, text: str) -> str:
        import pyautogui
        key_map = {
            "enter": "enter", "escape": "escape", "tab": "tab",
            "space": "space", "backspace": "backspace", "delete": "delete",
            "copy": ["ctrl", "c"], "paste": ["ctrl", "v"],
            "cut": ["ctrl", "x"], "undo": ["ctrl", "z"],
            "redo": ["ctrl", "y"], "save": ["ctrl", "s"],
            "select all": ["ctrl", "a"], "find": ["ctrl", "f"],
        }
        for k, hotkey in key_map.items():
            if k in text:
                if isinstance(hotkey, list):
                    pyautogui.hotkey(*hotkey)
                else:
                    pyautogui.press(hotkey)
                return f"Pressed {k}."
        return "Which key should I press?"

    def _system_info(self, text: str) -> str:
        import psutil
        cpu    = psutil.cpu_percent(interval=0.5)
        ram    = psutil.virtual_memory()
        disk   = psutil.disk_usage("/")
        lines  = [
            f"CPU: {cpu}%",
            f"RAM: {ram.percent}% used ({ram.available // 1024**2} MB free)",
            f"Disk: {disk.percent}% used ({disk.free // 1024**3} GB free)",
        ]
        try:
            import GPUtil
            gpus = GPUtil.getGPUs()
            if gpus:
                g = gpus[0]
                lines.append(f"GPU: {g.name} — {g.load*100:.0f}% load, {g.memoryUsed:.0f}/{g.memoryTotal:.0f} MB")
        except Exception:
            pass
        return ". ".join(lines) + "."

    # ── Register ──────────────────────────────────────────────────────────────
    def register(self) -> dict[str, callable]:
        return {
            r"\bopen\b":                       self._open_app,
            r"\bclose\b":                      self._close_app,
            r"\b(volume|mute|unmute)\b":       self._volume,
            r"\b(screenshot|capture screen)\b": self._screenshot,
            r"\b(shutdown|shut down|restart|reboot|sleep|hibernate|lock)\b": self._shutdown,
            r"\bcancel shutdown\b":             self._cancel_shutdown,
            r"\bclipboard\b":                   self._clipboard,
            r"\btype\s+\w":                     self._type_text,
            r"\b(press|hit)\s+(enter|escape|tab|ctrl|space|backspace|delete|copy|paste|cut|undo|redo|save|select all|find)\b": self._key_press,
            r"\b(system info|cpu|ram|memory|disk space|gpu)\b": self._system_info,
        }
