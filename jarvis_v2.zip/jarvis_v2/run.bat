@echo off
TITLE JARVIS v2
color 0B

:: Load .env file
if exist .env (
    for /F "tokens=1,2 delims==" %%A in (.env) do set %%A=%%B
)

echo  ╔══════════════════════════╗
echo  ║     JARVIS v2 Online     ║
echo  ╚══════════════════════════╝
echo.
echo  Press Ctrl+C to shut down
echo.

python main.py
pause
